module.exports = function () {
	var msg = "Este Modulo contem apenas uma String";
	
	return msg;
}